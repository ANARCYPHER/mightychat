class FontSizeModel {
  String? name;
  int? fontSize;

  FontSizeModel({this.name, this.fontSize});
}
